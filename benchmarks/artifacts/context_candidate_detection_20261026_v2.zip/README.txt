Controlled synthetic detection experiment, 2026-10-26. Method failed its precision/recall gate.
Original failures, raw local responses, exact scores, and frozen implementation bytes are retained.
Extract only into a NEW results subdirectory in the matching repository revision.
Run: python scripts/verify_context_candidate_diagnostic.py --run <new extracted directory> --output <new extracted directory>/verification_replay.json
Verification replays recorded responses; it does not run models, use credentials, or execute archived source.
Old heldout materials are exposed regression data, not independent acceptance. No inference-privacy proof.
