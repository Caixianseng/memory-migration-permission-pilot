# Source fact card reader: public synthetic development artifact

This package is one hand-authored synthetic development run, not anonymized
private memory. It contains original synthetic sources, PVT-bearing requests,
raw local model responses and final synthetic answers; these are linkable.

Legal joint results: F 28/32 (strict raw 24/32), Flat-ID 31/32, Source-ID 32/32.
Source-ID gains only one task in one story over the strong Flat-ID baseline.
All arms: 8/8 genuine missing-information UNKNOWN; 8/8 outsiders blocked before
models. One execution, exposed development stories; no generalization, stable
advantage, statistical significance, algorithm novelty or semantic privacy claim.
146 local generation posts (8 build + 18 labels + 120 answers), 76 encoder calls.
Fresh64 was not opened. Export and offline replay make no model calls.

Run from any directory with standard Python:

    python verification/verifier.py --input-root . --output offline_receipt.json

Use a new output filename. The verifier disables network/model execution, loads
the exact archived pure modules, reconstructs source ranges and equivalent
masked projections under a temporary authority, and recomputes saved metrics.
Original HMAC keys, map objects and Python object identity were intentionally
not preserved: this cannot independently verify the original process HMAC
signatures or provide tamperproof execution attestation. Journal/hash consistency
cannot defeat coordinated forgery. Original failed v1 and successful v2/v3
verification receipts are retained; the v1 metadata interpretation was corrected
without changing experimental artifacts. The current verifier adds import-origin
checking and supports this package layout.

manifest.json lists exact bytes and explicit provenance. Only transport_audit.json
is derived: its host executable and Python build metadata are omitted; original
and exported SHA256 values remain in the manifest. No key, RestorationMap, Entry,
user directory, credential or arbitrary result directory is exported.
