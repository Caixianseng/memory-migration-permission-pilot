# Candidate classifier diagnostic artifact

`flat/` preserves the four-condition flat classifier experiment (840 rows,
324 local generations). `gliclass/` preserves the three-arm comparison (360
rows, 111 new CPU encoder forwards). Both reuse the same 80 exposed development
and 40 exposed regression materials. They are negative development results;
default methods were not changed and no speed or novel privacy claim follows.

Models, credentials, restoration maps and recursive results snapshots are not
included. All entries are explicit allowlisted original bytes. Frozen source
comes from each pre-execution plan; audit_source is the current independent
verifier source and is not retroactively preregistered experiment code.

Use these artifacts in the matching project checkout. The existing public
`benchmarks/artifacts/context_candidate_detection_20261026_v2.zip` remains a
required external source dependency, SHA256:
`330d31c9e70980631dd3b67dc8a059512af77693e39870c2b8570b696effce43`.
It is not duplicated inside this ZIP. The included runtime/evaluation files are
synthetic originals from that already public artifact, not newly independent data.

After unpacking into a NEW directory below project/results, run the repository
verifiers (not automatically executing archived code). For UNPACK=that directory:

```powershell
python scripts/verify_candidate_decision_diagnostic.py --run UNPACK/flat --output UNPACK/flat/recheck_flat.json
python scripts/verify_gliclass_candidate_diagnostic.py UNPACK/gliclass --flat-reference UNPACK/flat --preflight-plan UNPACK/gliclass/preflight_plan.json --output UNPACK/gliclass/recheck_gliclass.json
```

These are zero-model saved-response/token/logit checks. Token replay does not
independently rerun tokenization or weights; process hook counts are not hardware
attestation. The original passed receipts report 2557 and 1117 checks.
